<template>
    <img class="mx-auto" alt="Vue logo" src="../assets/boilerplate.png" />
</template>
